package cyano.basemetals.registry;

public interface IOreDictionaryEntry {

	public abstract String getOreDictionaryName();
}
