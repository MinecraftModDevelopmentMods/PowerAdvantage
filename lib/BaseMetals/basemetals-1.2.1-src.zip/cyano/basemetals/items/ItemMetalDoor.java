package cyano.basemetals.items;

import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;

public class ItemMetalDoor extends net.minecraft.item.ItemDoor{

	public ItemMetalDoor(BlockDoor block) {
		super(block);
	}

}
